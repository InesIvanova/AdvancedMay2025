from OOP_3_inheritance.ex_1.project.fruit import Fruit

fruit = Fruit("tomato", "2025-10-09")
print(fruit.name)